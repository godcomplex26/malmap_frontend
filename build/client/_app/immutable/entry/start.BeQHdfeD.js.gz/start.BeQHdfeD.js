import{a as t}from"../chunks/entry.THagzjR9.js";export{t as start};
