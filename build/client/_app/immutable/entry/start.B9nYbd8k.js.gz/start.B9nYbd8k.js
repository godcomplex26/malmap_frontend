import{a as t}from"../chunks/entry.CZLTgY0W.js";export{t as start};
